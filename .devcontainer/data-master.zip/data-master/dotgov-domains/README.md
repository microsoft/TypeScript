# .gov domains

.gov domain data has moved to https://github.com/cisagov/dotgov-data.
